import numpy as np
import pandas as pd
from sklearn.externals import joblib
from sklearn.svm import SVC
import os


cli=range(1,58)
cli2=map(str,cli)

X=[]
y=[]

#print li

for i in cli2:
	print i
	df=pd.read_csv(os.path.join("../ClassCSV","Class"+i+".csv"))
	#ID=list(df.iloc[:,1])
	df=df.drop(df.columns[[0,1]],axis=1)
	mat=df.as_matrix()
	li=mat.tolist()
	X.extend(li)
	n=len(li)
	clid=[int(i)]*n
	y.extend(clid)

clf=SVC(probability=True,decision_function_shape='ovo')
clf.fit(X,y)
filename=os.path.join("./Model",'Model.pkl')
joblib.dump(clf,filename)

	
	
	
	
