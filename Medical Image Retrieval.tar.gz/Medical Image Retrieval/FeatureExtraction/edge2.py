import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('1877.png')
gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
#hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
edges = cv2.Canny(gray,1,255)
'''plt.subplot(121),plt.imshow(hsv,cmap = 'gray')
plt.title('Original Image'), plt.xticks([]), plt.yticks([])
plt.subplot(122),plt.imshow(edges,cmap = 'gray')
plt.title('Edge Image'), plt.xticks([]), plt.yticks([])

plt.savefig("edge.png")
plt.clf()
plt.close()'''
print len(edges)
lines = cv2.HoughLines(edges,1,np.pi/2,9)

    
#cv2.imwrite('detectP.jpg',img)
#plt.imshow(img)


lin=lines.flatten()
print len(lines)
thet=[]
k=1
n=len(lin)
while(k<n):
	thet.append(float(lin[k]))
	k+=2
	
print thet
	
			
	


