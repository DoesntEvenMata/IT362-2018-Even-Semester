import numpy as np
from sklearn.decomposition import PCA
import pandas as pd



#cli=range(1,58)
#cli2=map(str,cli)

featlist=[[x] for x in range(1,58)]
#print featlist

for i in range(57):
	featlist[i].append([])
	
#print featlist

df=pd.read_csv("Extract.csv")

ID=list(df.iloc[:,1])
clab=list(df.iloc[:,2])

#print clab
df2=df.drop(df.columns[[0,1,2]],axis=1)

#print df2

mat=df2.as_matrix()

pca=PCA(n_components=6)
rmat=pca.fit_transform(mat)
#print rmat
#print(pca.explained_variance_ratio_)

j=0  

#print list(rmat[0]) 
for i in rmat:
	#print i
	feat=list(i)
	feat.insert(0,ID[j])	
	featlist[clab[j]-1][1].append(feat)
	j+=1

#print featlist[0][0]
	
for lab,feat in featlist:
	csvN=str(lab)
	df=pd.DataFrame(feat)
	df.to_csv("../ClassCSV/Class"+csvN+".csv",index=True,header=False)
	

		
	



 	
