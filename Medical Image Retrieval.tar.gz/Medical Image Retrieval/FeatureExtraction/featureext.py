import cv2
import numpy as np
import scipy.stats as st
from skimage import io, color, img_as_ubyte
from skimage.feature import greycomatrix, greycoprops
import math
def getFeat(filename):
	feature=[]
	
	img = cv2.imread(filename,1)
	hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
	h = cv2.calcHist([hsv],[0],None,[256],[0, 256])	
	s = cv2.calcHist([hsv],[1],None,[256],[0, 256])
	v = cv2.calcHist([hsv],[2],None,[256],[0, 256])
	muh=np.mean(h)
	mus=np.mean(s)
	muv=np.mean(v)
	hsd=np.std(h)
	ssd=np.std(s)
	vsd=np.std(v)
	hsk=st.skew(h)
	ssk=st.skew(s)
	vsk=st.skew(v)
	feat1=[muh,mus,muv,hsd,ssd,vsd,hsk[0],ssk[0],vsk[0]]
	#print feat1
	feature.extend(feat1)
	img2=io.imread(filename)
	distances = [1]
	angles = [0, np.pi/4, np.pi/2, 3*np.pi/4]
	properties = ['energy', 'homogeneity','contrast','dissimilarity','correlation']

	try:
		glcm = greycomatrix(img2, 
		            distances=distances, 
		            angles=angles,
		            symmetric=True,
		            normed=True)
		#print glcm
		feat2 = np.hstack([greycoprops(glcm, prop).ravel() for prop in properties])
	except AssertionError:
		feat2=[0]*20
		#print feat2
	feature.extend(feat2)
	
	edges = cv2.Canny(hsv,1,255)
	lines = cv2.HoughLines(edges,1,np.pi/360,9)
	if lines is not None:
		lin=lines.flatten()
		#print len(lines)
		thet=[]
		k=1
		n=len(lin)
		while(k<n):
			thet.append(math.degrees(float(lin[k])))
			k+=2
	
		#print thet
		bins2=[]
		for i in range(73):
			bins2.append(i*5)
		
		freq,cul=np.histogram(thet,bins=bins2)
		#print len(freq)
	else:
		freq=[0]*72
	feature.extend(freq)
	return feature
	
	

#feature=getFeat("19979.png")
#print len(feature)

