import numpy as np
import pandas as pd
from sklearn.externals import joblib
import os
import cv2

cli=range(1,58)
cli2=map(str,cli)

clf=joblib.load(os.path.join("../SVM/Model",'Model.pkl'))

#print li

for i in cli2:
	print i
	clab=int(i)
	#epsilon=[]
	#omega=[]
	finaldat=[]
	df=pd.read_csv(os.path.join("../ClassCSV","Class"+i+".csv"))
	df2=pd.read_csv(os.path.join("../KMeans/KMCen","Class"+i+"Cen.csv"))
	ID=list(df.iloc[:,1])
	df=df.drop(df.columns[[0,1]],axis=1)
	mat=df.as_matrix()
	li=mat.tolist()
	count=0
	for j in li:
		probs=clf.predict_proba([j])
		eps=probs[0][clab-1]
		feat1=np.float32(j)
		nfeat1=np.ones(shape=(1,6))
		nfeat1=cv2.normalize(feat1,nfeat1,alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
		tot=0
		for k in range(len(df2.index)):
			feat2=list(df.iloc[k])		
			feat2=np.float32(feat2)
			nfeat2=np.ones(shape=(1,6))
			nfeat2=cv2.normalize(feat2,nfeat2,alpha=0, beta=1, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)
			a=cv2.compareHist(nfeat1,nfeat2,cv2.HISTCMP_CHISQR)
			tot+=a
		omg=tot/len(df2.index)
		final=[ID[count],eps,omg]
		final.extend(j)
		finaldat.append(final)
		count+=1
		#print omg
		#epsilon.append(eps)
		#omega.append(omg)
	df3=pd.DataFrame(data=finaldat,columns=['ID','Epsilon','Omega','Data','Data','Data','Data','Data','Data'])
	df3.to_csv("./ProbRank/Class"+i+"Rank.csv",index=True,header=True)
	
			
			
		
		
		
		
		
